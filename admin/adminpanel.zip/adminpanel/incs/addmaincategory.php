<?php

	if (isset($_GET["data"])) {
		echo "true";
	}else{
		echo "false";
	}

?>