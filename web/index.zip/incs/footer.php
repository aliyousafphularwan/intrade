	<!-- footer -->

	<footer class="footer mt-2" style="padding: 0px 50px;">
		
		<div class="row">
			
			<div class="fabout col-md-3 p-1">
				<p style="font-weight: bold;"> Company </p>
				<ul class="navbar-nav">
					<li class="nav-item"><a href="index.php?page=about"> About Us </a></li>
					<li class="nav-item"><a href="index.php?page=contact"> Contact Us </a></li>
					<li class="nav-item"><a href="index.php?page=terms"> Terms & Conditions </a></li>
					<li class="nav-item"><a href="index.php?page=privacy"> Privacy </a></li>
					<li class="nav-item"><a href="index.php?page=ship"> Shipping & Payments </a></li>
					<li class="nav-item"><a href="index.php?page=certificates"> Certificates </a></li>
					<li class="nav-item"><a href="index.php?page=events"> Events </a></li>
					<li class="nav-item"><a href="index.php?page=work"> How do we work </a></li>
					<li class="nav-item"><a href="index.php?page=team"> Team </a></li>
				</ul>
			</div>

			<div class="flinks col-md-5 p-1">
				<p style="font-weight: bold;"> Contact </p>
				<p class="p-0"> Intrade International 
				<br>Commissioner Road, Muhammad Pura, Sialkot-51310-Pakistan
				 <br><i class="fa fa-envelope"></i> <a href="mailto:info@intrade.com.pk" >info@intrade.com.pk</a> 
				 <br><i class="fa fa-phone"></i> +92-524-598233 
				<br><i class="fa fa-globe"></i> www.intrade.com.pk </p>
			</div>

			<div class="fcontact col-md-4 p-1">
				<p style="font-weight: bold;"> Catalogs </p>
				<a href="">Hand Tools Catalog</a><br>
				<a href="">Dental instruments Catalog</a>

				<div class="fsocial" style="margin-top: 20px;">
					<a class="m-3" href="https://www.facebook.com/IntradeInternational" target="_blank"> <i class="fa fa-facebook fa-2x"></i> </a>
					<a class="m-3" href="http://instagram.com/intradeinternational_official" target="_blank"> <i class="fa fa-instagram fa-2x"></i> </a>
					<a class="m-3" href="http://api.whatsapp.com/send?phone=+923358311414"> <i class="fa fa-whatsapp fa-2x"></i> </a>
				</div>

			</div>
		</div>
		<p class="ftr-btm"> &copy; 2009-2020 intrade.com.pk | Jewelry Tools & Instruments Company | All Rights Reserved </p>
	</footer>

	