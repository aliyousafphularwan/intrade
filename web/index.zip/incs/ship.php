
<div class="team">
	<p> <a href="index.php">Home</a> / <?php echo $_GET['page'];?> </p>
</div>
<div class="container p-5">
	
	<h4> Shipping & Payments </h4>

	<div class="p-5">
		Shipping modes:
		<br>
		By Air Cargo, DHL, FedEx and Sea.
	</div>

</div>