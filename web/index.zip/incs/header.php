<div class="tcnb">
	<div class="tcart" style="margin-top:-50px;margin-right: 20px; text-align: right;width: 100%;">
		<a href="index.php?page=cart"><i class="fa fa-shopping-cart" style="color: #000;"></i></a>
	</div>	
</div>
<div class="navbar cnb">
	<a href="index.php" class="brand-name"><img src="imgs/logo.png" width="180"></a>
	<ul class="tsrch2 mt-3">
		<form method="post">
			<input type="text" name="search" placeholder="search">
			<button><i class="fa fa-search"></i></button>
		</form>
	</ul>

	<div class="sandwich">
		<i class="fa fa-bars fa-2x"></i>
	</div>

	<ul class="navbar-nav cnbu">
		<li class="nav-item"><a class="nav-link" style="color: #003a31;" href="index.php">Home</a></li>
		<li class="nav-item"><a class="nav-link" style="color: #003a31;" href="index.php?page=about">About</a></li>
		<li class="nav-item"><a class="nav-link" style="color: #003a31;" href="index.php?page=products">Jewelry & Watch Tools</a></li>
		<li class="nav-item"><a class="nav-link" style="color: #003a31;" href="http://www.intrade-dental.com" target="_blank">Dental & Orthopedic Instruments</a></li>
		<li class="nav-item"><a class="nav-link" style="color: #003a31;" href="index.php?page=contact">Contact</a></li>
	</ul>
</div>