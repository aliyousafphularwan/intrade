<?php

	/**
	 * 
	 */
	class ProductDetails
	{
		function __construct($foo = 'hello')
		{
			$this->foo = $foo;
		}
	}

?>