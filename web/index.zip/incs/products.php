<div class="team">
	<p> <a href="index.php">Home</a> / <?php echo $_GET['page'];?> </p>
</div>

	<div class="container p-2">
		<div class="row cr">
			<div class="col-md-3">
				<h5>Categories</h5>
				<hr>
				<?php 

					$select = "SELECT * FROM sub_categories ORDER BY name ASC";
					$sres = mysqli_query($conn, $select);
					if (mysqli_num_rows($sres) > 0) {
						echo "<ul class='navbar-nav dul'>";

						while ($row = mysqli_fetch_assoc($sres)) {
							?>
							<li><a href="index.php?page=products&pid=<?php echo $row['id'];?>"> <?php echo $row["name"];?> </a></li>
							<?php
						}

						echo "</ul>";
					}else{
						echo "no categories found";
					}

				?>
			</div>
			<div class="col-md-9">

				<img src="imgs/pslider.png" class="img-fluid w-100">

				<hr>

				<h4 class="text-center"> Products </h4>

				<div class="row rp">

					<?php 

						if (!isset($_GET["pid"])) {
							
							$select = "SELECT * FROM sub_categories";
							$sres = mysqli_query($conn, $select);
							if (mysqli_num_rows($sres) > 0) {
								while ($row = mysqli_fetch_assoc($sres)) {
									?>

									<div class="col-md-4 my-2">
										<div class="card text-center">
										  <div class="card-body">
										  	<a href="index.php?page=products&pid=<?php echo $row['id'];?>">
										  	<img src="admin/uploads/imgs/<?php echo $row['cimg'];?>" class="img-fluid pimg w-100">
										    <h5 class="card-title"><?php echo $row['name'];?></h5>
										    </a>
										  </div>
										</div>
									</div>

									<?php
								}
							}else{
								echo "no category found.";
							}

						}else{
							
							$id = $_GET['pid'];  //
							$select = "SELECT * FROM products WHERE product_sub_cat = '$id'";
							$sres = mysqli_query($conn, $select);
							if (mysqli_num_rows($sres) > 0) {
								while ($row = mysqli_fetch_assoc($sres)) {
									?>

										<div class="col-md-4 my-2">
											<div class="card text-center">
											  <div class="card-body">
											  	<img src="admin/uploads/products/<?php echo $row['product_img'];?>" class="img-fluid pimg">
											    <h4 class="card-title"><?php echo $row['product_name'];?></h4>
											    <p class="card-text"><?php echo $row['smcat'];?></p>
											    <a href="#" class="btn btn-success"><i class="fa fa-heart"></i> &nbsp; Favorite</a>
											    <a href="index.php?page=product&spid=<?php echo $row['id'];?>" class="btn btn-info"><i class="fa fa-info"></i> &nbsp; Details</a>
											  </div>
											</div>
										</div>

									<?php
								}
							}else{
								echo "no products found";
							}
						}

					?>

				</div>

			</div>

		</div>
	</div>