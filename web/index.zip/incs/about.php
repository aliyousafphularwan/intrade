<!-- about -->

<div class="team">
	<p> <a href="index.php">Home</a> / <?php echo $_GET['page'];?> </p>
</div>
<div class="container about p-5">
		
	<div class="row about-inner">
		<div class="col-md-6">
			<img src="imgs/brand.jpeg" class="img-fluid" width="600">
		</div>
		<div class="col-md-6 about-col-rt">
			<h2 class="py-5"> About Company </h2>
			<p style="text-align: justify;">
					Greetings from Intrade International; We are manufacturers of Jewelry making hand tools,   Dental & Orthopedic instruments and providing nice quality products to meet the rising  demands of tools & dental industry.  This is a family business being carried by one to another generation.  We have all latest manufacturing facilities and have strict quality control check to make sure that each hand tool & instrument is of right standard.  We are well skilled in our profession as we have spent more than three decades in this field.    </p>

					<p style="text-align: justify;">We are committed to provide superior products that guarantees quality. Our goal is to provide high quality and cost-effective products at your door step. We look forward to have long term business relations with our worthy buyers and assure them of our best services for all times to come. We hope you would be kind in giving us an opportunity to supply you our products and look forward to have long term business relations/collaborations with our buyers.  
			</p>
			
			<div style=";width: 100%; text-align: right;">
				<p>Kindest regards,<br> 
				<b>Intrade International</b></p>
			</div>

		</div>
	</div>

</div>
