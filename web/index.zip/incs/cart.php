<div class="team">
	<p> <a href="index.php">Home</a> / <?php echo $_GET['page'];?> </p>
</div>
<div class="container">

	<h5> Product Inqury </h5>
	<form method="post">	<table class="table w-50">
		<tr>
			<th> Art # </th>
			<th> Name </th>
			<th> Category </th>
			<th> Quantity </th>
			<th> Action(s) </th>
		</tr>
	<?php

	if (isset($_SESSION["shop"])) {
		foreach ($_SESSION["shop"] as $key => $value) {
			?>

			<div class="container">
				
								
					<tr>
						<td> <?php echo $value["id"];?> </td>
						<td> <?php echo $value["name"];?> </td>
						<td> <?php echo $value["main"];?> </td>
						<td> <?php echo $value["qty"];?> </td>
						<td> <button class="btn btn-info"><i class="fa fa-pencil"></i></button> <button class="btn btn-danger"><i class="fa fa-trash"></i></button> </td>
					</tr>

			<?php
		}
	}else{
		echo "No Product(s) in the Cart";
	}

?>


					<tr>
						<td colspan="4"><button name="sendin" class="btn btn-success" style="float: right;"><i class="fa fa-paper-plane"></i> Send Inquiry </button> &nbsp; &nbsp;
						<button name="cflash" class="btn btn-danger" style="float: right;margin-right: 10px;"><i class="fa fa-trash"></i> Clear </button></td>
					</tr>
				</table>
				</form>
			</div>

<?php 

	if (isset($_POST["sendin"])) {
		
	}

	if (isset($_POST["cflash"])) {
		
		unset($_SESSION["shop"]);
		session_destroy();

	}

?>