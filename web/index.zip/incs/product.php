<div class="team">
	<p> <a href="index.php">Home</a> / <?php echo $_GET['page'];?> </p>
</div>

	<div class="container p-2">
		<div class="row cr">
			<div class="col-md-3">
				<h5>Categories</h5>
				<hr>
				<?php 

					$select = "SELECT * FROM sub_categories ORDER BY name ASC";
					$sres = mysqli_query($conn, $select);
					if (mysqli_num_rows($sres) > 0) {
						echo "<ul class='navbar-nav dul'>";

						while ($row = mysqli_fetch_assoc($sres)) {
							?>
							<li><a href="index.php?page=products&pid=<?php echo $row['name'];?>"> <?php echo $row["name"];?> </a></li>
							<?php
						}

						echo "</ul>";
					}

				?>
			</div>
			<div class="col-md-9">

				<img src="imgs/pslider.png" class="img-fluid w-100">

				<hr>

				<h4 class="text-center"> Product Details </h4>

				<div class="row rp">
					<?php 
						$id = $_GET['spid'];
						$select = "SELECT * FROM products WHERE id = '$id'";
						$sres = mysqli_query($conn, $select);
						if (mysqli_num_rows($sres) > 0) {
							while ($row = mysqli_fetch_assoc($sres)) {
								?>
								
								<div class="col-md-6">
									<img class="img-fluid" src="admin/uploads/products/<?php echo $row['product_img'];?>">
								</div>

								
								<div class="col-md-6">
									<form method="post">
									<div class="product-top">
										<h3> <?php echo $row['product_name'];?> </h3>
										<p> <?php echo $row['product_desc'];?> </p>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<hr>
									</div>

									<div>
										<p> <b>categories</b>: <a href="#"><?php echo $row['product_sub_cat'];?></a> > <a href="#"><?php echo $row['smcat'];?></a> </p>
										<p><b>Tags</b>: <a href="#"><?php echo $row['product_sub_cat'];?></a>,
											<a href="#"><?php echo $row['smcat'];?></a>
										</p>
										<hr>
									</div>

									<div>
										<input type="hidden" name="hid" value="<?php echo $row['product_art'];?>">
										<input type="hidden" name="hpname" value="<?php echo $row['product_name'];?>">
										<input type="hidden" name="hpmcat" value="<?php echo $row['product_sub_cat'];?>">
										<input type="hidden" name="hpscat" value="<?php echo $row['smcat'];?>">

										<p style="font-weight: bold;">Quantity</p>
										<input type="text" name="pqty" class="form-control w-50" value="1">
										<input type="submit" class="btn btn-success my-1" value="Inquire" name="a2c">
									</div>
								</form>
								</div>
								
								<?php
							}
						}

					?>
					
				</div>

			</div>

		</div>
	</div>

	<hr>

	<div class="container">
		
		<h5 class="text-center"> Related Products </h5>
		<marquee onmouseover="stop()" onmouseout="start()" scrolldelay="90">
		<div class="row text-center">
			<?php 

				$select = "SELECT * FROM products";
				$sres = mysqli_query($conn, $select);
				if (mysqli_num_rows($sres) > 0) {
					while ($row = mysqli_fetch_assoc($sres)) {
						?>

						<div class="col-md-4 my-2">
							<div class="card">
								<div class="card-body">
									<img width="50" src="admin/uploads/products/<?php echo $row['product_img'];?>" class="card-img img-fluid">
									<h4 class="card-title"><?php echo $row['product_name'];?></h4>
									<p class="card-text"><?php echo $row['product_desc'];?></p>
									<a href="index.php?page=product&spid=<?php echo $row['id'];?>" class="btn btn-info"><i class="fa fa-info"></i>&nbsp; Details</a>
								</div>
							</div>
						</div>

						<?php
					}
				}

			?>

		</div>
	</marquee>

	</div>

<?php

	if (isset($_POST['a2c'])) {

		// session_start();
		
		$id = $_POST['hid'];
		$name = $_POST['hpname'];
		$main = $_POST['hpmcat'];
		$sub = $_POST['hpscat'];
		$pqty = $_POST["pqty"];

		if (isset($_SESSION["shop"])) {
			$item_arr_id = array_column($_SESSION['shop'], 'id');
			if (!in_array($id, $item_arr_id)) {
				$count = count($_SESSION['shop']);
				$item_arr = array(
					'id'=>$id,
					'name'=>$name,
					'main'=>$main,
					'sub'=>$sub,
					'qty'=>$pqty
				);
				$_SESSION['shop'][$count] = $item_arr;
				print_r($item_arr);
			}else{
				echo "<script> alert('item already add to cart'); </script>";
			}
		}else{
			$item_arr = array(
					'id'=>$id,
					'name'=>$name,
					'main'=>$main,
					'sub'=>$sub,
					'qty'=>$pqty
				);
				$_SESSION['shop'][0] = $item_arr;
		}

	}

?>