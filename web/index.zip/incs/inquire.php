<div class="team">
	<p> <a href="index.php">Home</a> / <?php echo $_GET['page'];?> </p>
</div>
<div class="container-fluid" style="position: relative;">
	
	<h5> Send Inquiry </h5>

	<div class="row">
		<div class="col-md-6">
			<form method="post">

				<div>
					<p> Your Name </p>
					<input type="text" name="sname" class="form-control" placeholder="eg. Ali Yousaf" required> 			
				</div>

				<div>
					<p> Your Email </p>
					<input type="email" name="smail" class="form-control" placeholder="eg. user@company.domain" required> 			
				</div>

				<div>
					<p> Your Company </p>
					<input type="text" name="scom" class="form-control" placeholder="eg. Google Inc" required> 			
				</div>
				<div>
					<p> Message </p>
					<textarea name="smsg" cols="5" rows="10" class="form-control" placeholder="Message" required></textarea>
				</div>

				<div>
					<button name="sendin" class="btn btn-success" style="margin: 20px; float: right;"> <i class="fa fa-paper-plane"></i> &nbsp;Send </button>
				</div>
				
			</form>
		</div>

		<div class="col-md-6">
			<?php 

				if (isset($_SESSION["shop"])) {
					foreach ($_SESSION["shop"] as $key => $value) {
							?>

							<table class="table">
								<tr>
									<th> Art # </th>
									<th> Name </th>
									<th> Category </th>
									<th> Quantity </th>
								</tr>
								<tr>
									<td> <?php echo $value['id'];?> </td>
									<td> <?php echo $value['name'];?> </td>
									<td> <?php echo $value['main'];?> </td>
									<td> <?php echo $value['qty'];?> </td>
								</tr>
							</table>

							<?php
						}	
				}else{
					echo "cart is empty";
				}

			?>
		</div>

	</div>

</div>

<?php 

	if (isset($_POST["sendin"])) {
		
		$mailto = "victamoflove@gmail.com";

		$name = $_POST["sname"];
		$email = $_POST["smail"];
		$company = $_POST["scom"];
		$msg = $_POST["smsg"];
		$headers = "From: sender\'s email";

		if (mail($mailto, $company, $msg, $headers)) {
			echo "<script> alert('Email Sent Successfully'); </script>";
		}else{
			echo "<script> alert('Email not Sent'); </script>";
		}


	}

?>