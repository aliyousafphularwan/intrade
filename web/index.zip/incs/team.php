
<div class="team">
	<p> <a href="index.php">Home</a> / <?php echo $_GET['page'];?> </p>
</div>
<div class="container p-5">
	
	<h4> Team of Professionals </h4>

	<div class="row">
		


	</div>

</div>