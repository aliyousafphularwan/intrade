<?php 

	$select = "SELECT * sub_category";

?>