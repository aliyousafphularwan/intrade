<?php 

	$select = "SELECT * sub_category";
	$sres = mysqli_query($conn, $select);
	if (mysqli_num_rows($sres) > 0) {
		while ($row = mysqli_fetch_assoc($sres)) {
			?>
			<table>
				<tr>
					<td><?php echo $row['id'];?></td>
					<td><?php echo $row['name'];?></td>
				</tr>
			</table>
			<?php
		}
	}

?>